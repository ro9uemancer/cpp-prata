// name: c00_e00
// description: 
// author: ro9uemancer

#include <iostream>
#include <conio.h>

using namespace std;


int main()
{


	_getch();
	return 0;
}