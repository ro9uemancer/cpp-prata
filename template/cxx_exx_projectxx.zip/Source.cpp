// name: cxx_exx_projectxxx
// tags: #template
// author: ro9uemancer

#include <iostream>
#include <conio.h>

using namespace std;


int main()
{


	_getch();
	return 0;
}