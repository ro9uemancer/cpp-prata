// name: project001_c01_e01
// tags: #helloworld #template
// author: ro9uemancer 

#include <iostream>
#include <conio.h>

using namespace std;


int main()
{
	

	_getch();
	return 0;
}